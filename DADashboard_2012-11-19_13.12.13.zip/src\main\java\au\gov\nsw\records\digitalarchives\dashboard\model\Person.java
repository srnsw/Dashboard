package au.gov.nsw.records.digitalarchives.dashboard.model;

import javax.persistence.Id;

import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.jpa.activerecord.RooJpaActiveRecord;
import org.springframework.roo.addon.tostring.RooToString;

import com.google.gson.annotations.Expose;

@RooJavaBean
@RooToString
@RooJpaActiveRecord
public class Person {
	
	@Expose
	@Id
	private Long id;
	@Expose
	private String name;
	@Expose
	private String agency;
	@Expose
	private String role;
	@Expose
	private String contactDetails;
}
